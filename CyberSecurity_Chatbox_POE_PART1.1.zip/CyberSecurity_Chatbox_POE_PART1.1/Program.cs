﻿using System;
using System.IO;
using System.Media;
using System.Threading;

class Program
{
    static void Main()
    {
        Console.Title = "Cyber Times With Abo";

        BootSequence();
        PlayVoiceGreeting();
        DisplayLogo();

        string userName = AskUserName();
        ShowProfessionalGreeting(userName);

        StartChat(userName);
    }

    // =========================================================
    // 🚀 BOOT SEQUENCE — VISUAL MEDIA EFFECT
    // =========================================================
    static void BootSequence()
    {
        Console.ForegroundColor = ConsoleColor.Green;

        TypeText("Initializing Cyber Times Security System...");
        TypeText("Loading threat intelligence modules...");
        TypeText("Establishing secure environment...");

        Console.Write("\nSystem booting");
        for (int i = 0; i < 5; i++)
        {
            Console.Write(".");
            Thread.Sleep(400);
        }

        Console.WriteLine("\nSystem ready.\n");
        Console.ResetColor();
    }

    // =========================================================
    // External Chatbot Integration (added without changing existing logic)
    // The user's standalone chatbot code was adapted into this helper class.
    // =========================================================
    static class ExternalChatbot
    {
        public static void Run()
        {
            Console.WriteLine("=== Cybersecurity Awareness Chatbot ===");
            Console.WriteLine("Type a topic number or keyword. Type 'exit' to quit.\n");

            while (true)
            {
                ShowMenuForExternal();

                Console.Write("\nYour choice: ");
                string input = Console.ReadLine()?.Trim().ToLower();

                // ✅ INPUT VALIDATION — handle empty input
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("⚠️ You entered nothing. Please type a number or topic.");
                    continue;
                }

                // ✅ Exit option
                if (input == "exit")
                {
                    Console.WriteLine("Stay safe online. Returning to main menu...");
                    break;
                }

                // explicit menu choice to return to main menu
                if (input == "0" || input == "back")
                {
                    Console.WriteLine("Returning to main menu...");
                    break;
                }

                // ✅ PROCESS INPUT
                string response = GetResponseForExternal(input);

                // Print responses using the same typing animation as the main program
                TypeText(response);
                Console.WriteLine("\n----------------------------------------\n");
            }
        }

        static void ShowMenuForExternal()
        {
            // display the same boxed menu layout as the main DisplayMenu (with same color)
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(@"
╔════════════════════ MENU ════════════════════╗
║ 0 — Return to Main Menu                      ║
║ 1 — Password Safety                          ║
║ 2 — Phishing                                 ║
║ 3 — Malware                                  ║
║ 4 — Social Engineering                       ║
║ 5 — Two-Factor Authentication                ║
║ 6 — Safe Browsing                            ║
║ 7 — Ransomware                               ║
║ 8 — Public Wi-Fi Safety                      ║
║ 9 — Identity Theft                           ║
║ 10 — Software Updates                        ║
╚══════════════════════════════════════════════╝
");
            Console.ResetColor();
        }

        static string GetResponseForExternal(string input)
        {
            // Build the same topic map used elsewhere so free-form queries and misspellings
            var topics = new System.Collections.Generic.Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase)
            {
                { "password", "Strong password security is one of the most important ways to protect your online accounts. A secure password should be long, complex, and unique for each account. Avoid using personal information such as your name, birthdate, or common words, as attackers can easily guess these. Instead, use a combination of uppercase and lowercase letters, numbers, and symbols. It is also highly recommended to use a password manager, which can generate and store strong passwords safely. Reusing passwords across multiple websites is dangerous because if one site is compromised, all your accounts become vulnerable." },
                { "phishing", "Phishing is a cyberattack where criminals pretend to be legitimate organizations to trick you into revealing sensitive information such as passwords, banking details, or personal data. These attacks usually arrive through emails, SMS messages, or fake websites that look authentic. Warning signs include urgent language, unexpected attachments, suspicious links, and requests for confidential information. Always verify the sender’s address and avoid clicking links from unknown sources. If unsure, go directly to the official website instead of using the provided link." },
                { "malware", "Malware is malicious software designed to damage, disrupt, or gain unauthorized access to your device. Common types include viruses, worms, spyware, and trojans. Malware can be installed when downloading files from untrusted sources, opening infected email attachments, or visiting compromised websites. Once installed, it can steal information, slow down your device, or allow hackers to control your system remotely. Using updated antivirus software, avoiding suspicious downloads, and keeping your operating system updated are key defenses." },
                { "social engineering", "Social engineering attacks manipulate human psychology rather than technical vulnerabilities. Attackers may pretend to be trusted individuals such as bank officials, IT staff, or coworkers to convince you to reveal confidential information or perform unsafe actions. These attacks often rely on urgency, fear, or curiosity to pressure victims into acting quickly. Always verify identities before sharing sensitive information, especially through phone calls or messages. Organizations typically have procedures and will not ask for passwords directly." },
                { "2fa", "Two-Factor Authentication (2FA) adds an extra layer of security beyond just a password. It requires a second form of verification, such as a code sent to your phone, an authentication app, or biometric data like a fingerprint. Even if a hacker steals your password, they cannot access your account without the second factor. Enabling 2FA on important accounts such as email, banking, and social media significantly reduces the risk of unauthorized access." },
                { "safe browsing", "Safe browsing involves protecting yourself while navigating the internet. Always check that websites use HTTPS, which indicates a secure connection. Avoid downloading files from unknown websites and be cautious of pop-ups claiming your device is infected. Using modern browsers with built-in security features and keeping them updated helps block dangerous sites automatically. Additionally, consider using browser extensions that prevent tracking and malicious scripts." },
                { "ransomware", "Ransomware is a type of malware that encrypts your files and demands payment to restore access. Victims are often instructed to pay in cryptocurrency, making it difficult to trace the attackers. Paying the ransom does not guarantee file recovery and encourages further criminal activity. The best defense is prevention: regularly back up important data, avoid suspicious attachments, and keep security software updated. If infected, disconnect from the network immediately to prevent the spread to other devices." },
                { "public wifi", "Public Wi-Fi networks, such as those in cafes or airports, are convenient but often insecure. Attackers can intercept data transmitted over these networks, potentially capturing passwords, emails, or financial information. Avoid accessing sensitive accounts while connected to public Wi-Fi unless you use a Virtual Private Network (VPN), which encrypts your internet traffic. Also, disable automatic connection to open networks and ensure file sharing is turned off when using public connections." },
                { "identity theft", "Identity theft occurs when criminals steal your personal information to commit fraud, such as opening bank accounts or making purchases in your name. Information can be obtained through phishing, data breaches, or social media oversharing. Protect yourself by limiting the personal details you share online, monitoring financial statements regularly, and using credit alerts if available. If identity theft occurs, report it immediately to your bank and relevant authorities to minimize damage." },
                { "updates", "Software updates are essential for security because they patch vulnerabilities that attackers exploit. Outdated systems are one of the most common entry points for cybercriminals. Updates often include fixes for newly discovered security flaws, performance improvements, and new protection features. Enable automatic updates whenever possible for your operating system, applications, and antivirus software to ensure you remain protected without needing manual intervention." }
            };

            string lower = (input ?? string.Empty).ToLower();

            // handle numeric menu choices quickly
            if (lower == "1" || lower == "password") return topics["password"];
            if (lower == "2" || lower.Contains("phish")) return topics["phishing"];
            if (lower == "3" || lower == "malware") return topics["malware"];
            if (lower == "4" || lower.Contains("social")) return topics["social engineering"];
            if (lower == "5" || lower == "2fa") return topics["2fa"];
            if (lower == "6" || lower.Contains("browse")) return topics["safe browsing"];
            if (lower == "7" || lower == "ransomware") return topics["ransomware"];
            if (lower == "8" || lower.Contains("wifi")) return topics["public wifi"];
            if (lower == "9" || lower.Contains("identity")) return topics["identity theft"];
            if (lower == "10" || lower.Contains("update") || lower.Contains("patch")) return topics["updates"];

            // Tokenize input
            var tokens = new System.Collections.Generic.List<string>();
            foreach (var t in System.Text.RegularExpressions.Regex.Split(lower, "[^a-z0-9]+"))
            {
                if (!string.IsNullOrEmpty(t)) tokens.Add(t);
            }

            var matched = new System.Collections.Generic.List<string>();
            foreach (var kv in topics)
            {
                if (lower.Contains(kv.Key)) { matched.Add(kv.Key); continue; }
                var keyTokens = kv.Key.Split(' ');
                foreach (var kt in keyTokens)
                {
                    if (tokens.Contains(kt)) { matched.Add(kv.Key); break; }
                }
            }

            if (matched.Count > 0)
            {
                // Combine multiple answers
                return string.Join("\n\n", matched.ConvertAll(k => topics[k]));
            }

            // Fuzzy suggestions
            var suggestions = new System.Collections.Generic.List<string>();
            foreach (var kv in topics)
            {
                var keyTokens = kv.Key.Split(' ');
                foreach (var kt in keyTokens)
                {
                    foreach (var it in tokens)
                    {
                        int dist = LevenshteinDistance(kt, it);
                        int threshold = Math.Max(1, kt.Length / 3);
                        if (dist <= threshold)
                        {
                            if (!suggestions.Contains(kv.Key)) suggestions.Add(kv.Key);
                        }
                    }
                }
            }

            if (suggestions.Count > 0)
            {
                foreach (var s in suggestions)
                {
                    TypeText($"I think you meant \"{s}\". Please type 'yes' or 'no':");
                    Console.Write("Your choice: ");
                    string reply = Console.ReadLine()?.Trim().ToLower();
                    if (!string.IsNullOrEmpty(reply) && (reply.StartsWith("y") || reply == "yes"))
                    {
                        return topics[s];
                    }
                }
            }

            return "I didn’t quite understand that. Could you please rephrase your question or choose a number from the menu? You can type topics such as 'phishing', 'malware', or 'password', or simply enter the corresponding number. My goal is to help you stay safe online, so feel free to try again.";
        }
    }

    // =========================================================
    // 🔊 VOICE GREETING
    // =========================================================
    static void PlayVoiceGreeting()
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "cyber.wav");

            if (File.Exists(path))
            {
                SoundPlayer player = new SoundPlayer(path);
                player.Load();
                player.PlaySync();
            }
            else
            {
                Console.WriteLine("Voice greeting file not found.");
            }
        }
        catch
        {
            Console.WriteLine("Audio playback error.");
        }
    }

    // =========================================================
    // 🌐 CREATIVE ASCII LOGO
    // =========================================================
    static void DisplayLogo()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;

        Console.WriteLine(@"
╔══════════════════════════════════════════════════════╗
║   ██████╗██╗   ██╗██████╗ ███████╗██████╗            ║
║  ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗           ║
║  ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝           ║
║  ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗           ║
║  ╚██████╗   ██║   ██████╔╝███████╗██║  ██║           ║
║   ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝           ║
║                                                      ║
║             CYBER TIMES WITH ABO                     ║
║        Cybersecurity Awareness Assistant             ║
╚══════════════════════════════════════════════════════╝
");

        Console.ResetColor();
    }

    // =========================================================
    // 👤 ASK USER NAME WITH VALIDATION
    // =========================================================
    static string AskUserName()
    {
        string name;

        // persistent usage counts stored in a simple text file in app directory
        string countsPath = Path.Combine(AppContext.BaseDirectory, "user_counts.txt");

        while (true)
        {
            Console.Write("\nPlease enter your name: ");
            name = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(name))
                break;

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Name cannot be empty. Please try again.");
            Console.ResetColor();
        }

        name = name.Trim();

        try
        {
            var counts = LoadUserCounts(countsPath);
            counts.TryGetValue(name, out int prev);
            int updated = prev + 1;
            counts[name] = updated;
            SaveUserCounts(countsPath, counts);

            // if user has used the system at least once before (this is now 2nd or more visit)
            if (prev >= 1)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                TypeText($"Hey, welcome back {name}.");
                Console.ResetColor();
            }
        }
        catch
        {
            // non-fatal: ignore persistence errors and continue
        }

        return name;
    }

    // Simple persistent storage helpers (format: name:count per line)
    static System.Collections.Generic.Dictionary<string, int> LoadUserCounts(string path)
    {
        var dict = new System.Collections.Generic.Dictionary<string, int>(System.StringComparer.OrdinalIgnoreCase);
        if (!File.Exists(path)) return dict;

        foreach (var line in File.ReadAllLines(path))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var idx = line.LastIndexOf(':');
            if (idx <= 0) continue;
            var n = line.Substring(0, idx).Trim();
            var s = line.Substring(idx + 1).Trim();
            if (int.TryParse(s, out int v)) dict[n] = v;
        }

        return dict;
    }

    static void SaveUserCounts(string path, System.Collections.Generic.Dictionary<string, int> dict)
    {
        try
        {
            var lines = new System.Collections.Generic.List<string>();
            foreach (var kv in dict)
            {
                lines.Add($"{kv.Key}:{kv.Value}");
            }
            File.WriteAllLines(path, lines);
        }
        catch
        {
            // ignore write failures
        }
    }

    // =========================================================
    // 👋 PROFESSIONAL GREETING
    // =========================================================
    static void ShowProfessionalGreeting(string name)
    {
        Console.ForegroundColor = ConsoleColor.Green;

        TypeText($"\nWelcome, {name}.");
        TypeText("It is a pleasure to have you here.");
        TypeText("I am your Cyber Times assistant, designed to help you understand cybersecurity risks and protect yourself online.");
        TypeText("You may ask about passwords, scams, malware, privacy, or safe browsing.");

        Console.ResetColor();
    }

    // =========================================================
    // 💬 CHAT SYSTEM — DEPTH & VARIETY
    // =========================================================
    static void StartChat(string name)
    {
        while (true)
        {
            DisplayMenu();

            Console.Write("\nYour choice: ");
            string input = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                ShowError("Please enter a valid option.");
                continue;
            }

            switch (input)
            {
                case "1":
                    TypeText("I am operating optimally and ready to assist you. I can provide detailed guidance on cybersecurity topics, explain risks, and suggest practical steps to protect your online accounts and devices. Ask me about passwords, phishing, malware, privacy practices, safe browsing, or how to respond to suspicious activity, and I will give clear, actionable advice.");
                    break;

                case "2":
                    TypeText("My purpose is to educate users about digital threats and promote safe online behaviour. I provide explanations of common attack types, best practices to reduce risk, and step-by-step recommendations you can apply immediately. Whether you need help selecting a password manager, recognizing scam emails, or hardening your personal devices, I aim to make cybersecurity understandable and practical.");
                    break;

                case "3":
                    TypeText("Strong password security is one of the most important ways to protect your online accounts. A secure password should be long, complex, and unique for each account. Avoid using personal information such as your name or birthdate. Use a mix of uppercase and lowercase letters, numbers, and symbols, or let a password manager generate and store strong random passwords for you. Enable multi-factor authentication where available and change passwords immediately if you suspect a breach. Regularly review account activity and use unique passwords per site to prevent credential reuse attacks.");
                    break;

                case "4":
                    TypeText("Phishing is a deceptive attack where criminals impersonate trusted organizations to steal credentials or personal data. These messages often urge immediate action, contain unexpected attachments, or include links to fake websites. Inspect the sender's address, hover over links to preview URLs, and never enter credentials from an email link—navigate directly to the official site. Be cautious with unsolicited requests for sensitive data and verify by contacting the organization through official channels. Report suspicious messages to your provider or IT team.");
                    break;

                case "5":
                    TypeText("Safe browsing protects your data while using the web. Always confirm a site uses HTTPS before entering sensitive information, and check for the correct domain to avoid impostor sites. Avoid downloading files or plugins from untrusted sources, be skeptical of pop-ups claiming your device is infected, and keep your browser updated so built-in protections can block malicious pages. Consider browser extensions that block trackers and malicious scripts, and use a reputable antivirus and ad-blocker for an extra layer of protection.");
                    break;

                case "6":
                    TypeText("Malware is software designed to harm or compromise systems, including viruses, trojans, spyware, and ransomware. It spreads via malicious downloads, infected attachments, or compromised websites. Use updated antivirus software, avoid running unknown executables, and keep your operating system and applications patched. Regularly back up important data to an offline or immutable location. If you suspect infection, disconnect from networks, run scans with trusted tools, and seek professional support to contain and remediate the issue.");
                    break;

                case "7":
                    TypeText("Public Wi-Fi networks, such as those in cafes or airports, are convenient but often insecure. Attackers can intercept unencrypted traffic and capture credentials or personal information. Avoid accessing sensitive accounts on public Wi-Fi unless you use a trusted VPN that encrypts your traffic. Disable automatic connection to open networks, turn off file sharing, and prefer your mobile data connection for sensitive tasks. When using public networks, verify the network name with staff and avoid entering passwords or payment details.");
                    break;

                case "9":
                    // Launch external chatbot integration (preserves existing behavior)
                    ExternalChatbot.Run();
                    break;

                case "8":
                    ExitProgram(name);
                    return;

                default:
                    // Free-form question handling with fuzzy matching for misspellings.
                    string lower = input.ToLower();

                    // Map canonical topic keys to their full answers
                    var topics = new System.Collections.Generic.Dictionary<string, string>(System.StringComparer.OrdinalIgnoreCase)
                    {
                        { "password", "Strong password security is one of the most important ways to protect your online accounts. A secure password should be long, complex, and unique for each account. Avoid using personal information such as your name or birthdate. Use a mix of uppercase and lowercase letters, numbers, and symbols, or let a password manager generate and store strong random passwords for you. Enable multi-factor authentication where available and change passwords immediately if you suspect a breach. Regularly review account activity and use unique passwords per site to prevent credential reuse attacks." },
                        { "phishing", "Phishing is a deceptive attack where criminals impersonate trusted organizations to steal credentials or personal data. These messages often urge immediate action, contain unexpected attachments, or include links to fake websites. Inspect the sender's address, hover over links to preview URLs, and never enter credentials from an email link—navigate directly to the official site. Be cautious with unsolicited requests for sensitive data and verify by contacting the organization through official channels. Report suspicious messages to your provider or IT team." },
                        { "malware", "Malware is software designed to harm or compromise systems, including viruses, trojans, spyware, and ransomware. It spreads via malicious downloads, infected attachments, or compromised websites. Use updated antivirus software, avoid running unknown executables, and keep your operating system and applications patched. Regularly back up important data to an offline or immutable location. If you suspect infection, disconnect from networks, run scans with trusted tools, and seek professional support to contain and remediate the issue." },
                        { "ransomware", "Ransomware is a type of malware that encrypts your files and demands payment to restore access. Victims are often instructed to pay in cryptocurrency, making it difficult to trace the attackers. Paying the ransom does not guarantee file recovery and encourages further criminal activity. The best defense is prevention: regularly back up important data, avoid suspicious attachments, and keep security software updated. If infected, disconnect from the network immediately to prevent the spread to other devices." },
                        { "public wifi", "Public Wi-Fi networks, such as those in cafes or airports, are convenient but often insecure. Attackers can intercept unencrypted traffic and capture credentials or personal information. Avoid accessing sensitive accounts while connected to public Wi-Fi unless you use a Virtual Private Network (VPN), which encrypts your internet traffic. Also, disable automatic connection to open networks and ensure file sharing is turned off when using public connections." },
                        { "safe browsing", "Safe browsing protects your data while using the web. Always confirm a site uses HTTPS before entering sensitive information, and check for the correct domain to avoid impostor sites. Avoid downloading files or plugins from untrusted sources, be skeptical of pop-ups claiming your device is infected, and keep your browser updated so built-in protections can block malicious pages. Consider browser extensions that block trackers and malicious scripts, and use a reputable antivirus and ad-blocker for an extra layer of protection." },
                        { "updates", "Software updates are essential for security because they patch vulnerabilities that attackers exploit. Outdated systems are one of the most common entry points for cybercriminals. Updates often include fixes for newly discovered security flaws, performance improvements, and new protection features. Enable automatic updates whenever possible for your operating system, applications, and antivirus software to ensure you remain protected without needing manual intervention." },
                        { "identity theft", "Identity theft occurs when criminals steal your personal information to commit fraud, such as opening bank accounts or making purchases in your name. Information can be obtained through phishing, data breaches, or social media oversharing. Protect yourself by limiting the personal details you share online, monitoring financial statements regularly, and using credit alerts if available. If identity theft occurs, report it immediately to your bank and relevant authorities to minimize damage." },
                        { "social engineering", "Social engineering attacks manipulate human psychology rather than technical vulnerabilities. Attackers may pretend to be trusted individuals such as bank officials, IT staff, or coworkers to convince you to reveal confidential information or perform unsafe actions. These attacks often rely on urgency, fear, or curiosity to pressure victims into acting quickly. Always verify identities before sharing sensitive information, especially through phone calls or messages. Organizations typically have procedures and will not ask for passwords directly." },
                        { "2fa", "Two-Factor Authentication (2FA) adds an extra layer of security beyond just a password. It requires a second form of verification, such as a code sent to your phone, an authentication app, or biometric data like a fingerprint. Even if a hacker steals your password, they cannot access your account without the second factor. Enabling 2FA on important accounts such as email, banking, and social media significantly reduces the risk of unauthorized access." }
                    };

                    // Tokenize user input to compare individual words
                    var tokens = new System.Collections.Generic.List<string>();
                    foreach (var t in System.Text.RegularExpressions.Regex.Split(lower, "[^a-z0-9]+"))
                    {
                        if (!string.IsNullOrEmpty(t)) tokens.Add(t);
                    }

                    var matched = new System.Collections.Generic.List<string>();

                    // Exact contains checks first (handles multi-word phrases too)
                    foreach (var kv in topics)
                    {
                        if (lower.Contains(kv.Key))
                        {
                            matched.Add(kv.Key);
                        }
                        else
                        {
                            // check if any token equals a token from the key
                            var keyTokens = kv.Key.Split(' ');
                            foreach (var kt in keyTokens)
                            {
                                foreach (var it in tokens)
                                {
                                    if (it == kt)
                                    {
                                        matched.Add(kv.Key);
                                        break;
                                    }
                                }
                                if (matched.Contains(kv.Key)) break;
                            }
                        }
                    }

                    if (matched.Count > 0)
                    {
                        // answer all matched topics
                        foreach (var key in matched)
                        {
                            TypeText(topics[key]);
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        // No exact match — attempt fuzzy suggestions
                        var suggestions = new System.Collections.Generic.List<string>();
                        foreach (var kv in topics)
                        {
                            var keyTokens = kv.Key.Split(' ');
                            foreach (var kt in keyTokens)
                            {
                                foreach (var it in tokens)
                                {
                                    int dist = LevenshteinDistance(kt, it);
                                    int threshold = Math.Max(1, kt.Length / 3);
                                    if (dist <= threshold)
                                    {
                                        if (!suggestions.Contains(kv.Key)) suggestions.Add(kv.Key);
                                    }
                                }
                            }
                        }

                        if (suggestions.Count > 0)
                        {
                            // Ask user to confirm each suggestion in order
                            bool handled = false;
                            foreach (var s in suggestions)
                            {
                                TypeText($"I think you meant \"{s}\". Please type 'yes' or 'no':");
                                Console.Write("Your choice: ");
                                string reply = Console.ReadLine()?.Trim().ToLower();
                                if (!string.IsNullOrEmpty(reply) && (reply.StartsWith("y") || reply == "yes"))
                                {
                                    TypeText(topics[s]);
                                    Console.WriteLine();
                                    handled = true;
                                    break;
                                }
                                // if user says no, try next suggestion
                            }

                            if (!handled)
                            {
                                TypeText("Sorry, I can't answer that at the moment. I am still updating and will provide that level of information soon.");
                            }
                        }
                        else
                        {
                            TypeText("Sorry, I can't answer that at the moment. I am still updating and will provide that level of information soon.");
                        }
                    }

                    break;
            }
        }
    }

    // =========================================================
    // 📋 MENU UI
    // =========================================================
    static void DisplayMenu()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;

        Console.WriteLine(@"
╔════════════════════ MENU ════════════════════╗
║ 1 — How are you?                             ║
║ 2 — What is your purpose?                    ║
║ 3 — Password Safety                          ║
║ 4 — Phishing Awareness                       ║
║ 5 — Safe Browsing                            ║
║ 6 — Malware Information                      ║
║ 7 — Public Wi-Fi Risks                       ║
║ 8 — Exit                                     ║
║ 9 — Extended Topics                          ║
╚══════════════════════════════════════════════╝
");

        Console.ResetColor();
    }

    // =========================================================
    // ❌ ERROR DISPLAY
    // =========================================================
    static void ShowError(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ResetColor();
    }

    // =========================================================
    // ✨ TYPING ANIMATION
    // =========================================================
    static void TypeText(string text)
    {
        foreach (char c in text)
        {
            Console.Write(c);
            Thread.Sleep(18);
        }
        Console.WriteLine();
    }

    // Levenshtein distance helper to detect misspellings
    static int LevenshteinDistance(string a, string b)
    {
        if (string.IsNullOrEmpty(a)) return string.IsNullOrEmpty(b) ? 0 : b.Length;
        if (string.IsNullOrEmpty(b)) return a.Length;

        int[,] d = new int[a.Length + 1, b.Length + 1];
        for (int i = 0; i <= a.Length; i++) d[i, 0] = i;
        for (int j = 0; j <= b.Length; j++) d[0, j] = j;

        for (int i = 1; i <= a.Length; i++)
        {
            for (int j = 1; j <= b.Length; j++)
            {
                int cost = a[i - 1] == b[j - 1] ? 0 : 1;
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
            }
        }

        return d[a.Length, b.Length];
    }

    // =========================================================
    // 👋 EXIT MESSAGE
    // =========================================================
    static void ExitProgram(string name)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;

        TypeText($"\nGoodbye, {name}.");
        TypeText("Thank you for using Cyber Times With Abo.");
        TypeText("Stay vigilant and stay safe online.");

        Console.ResetColor();
    }
}