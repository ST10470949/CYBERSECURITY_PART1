using System;
using System.IO;
using System.Media;

static class AudioPlayer
{
    public static void PlayIfExists(string filename)
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, filename);
            if (File.Exists(path))
            {
                SoundPlayer player = new SoundPlayer(path);
                player.Load();
                player.PlaySync();
            }
        }
        catch
        {
            // ignore audio errors
        }
    }
}
