using System;

class User
{
    public string Name { get; set; }

    public User(string name)
    {
        Name = name ?? string.Empty;
    }
}

// Simple global user store used by Program and ExternalChatbot
static class UserStore
{
    public static string CurrentUserName { get; set; } = string.Empty;
}
