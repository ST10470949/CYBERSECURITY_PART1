using System;

static class Chatbot
{
    // The Chatbot helper previously handled padding/truncation to an exact
    // word count. The user requested to manage responses directly, so the
    // BuildAnswer functionality has been removed. Keep the helper minimal
    // with a simple EnsureBodyLength method available if needed.
    public static string EnsureBodyLength(string baseText, int targetWords)
    {
        var words = new System.Collections.Generic.List<string>();
        foreach (var w in System.Text.RegularExpressions.Regex.Split(baseText ?? string.Empty, "\\s+"))
        {
            if (!string.IsNullOrEmpty(w)) words.Add(w);
        }

        // Short filler used only when developer opts to call this method
        string filler = "Following these recommended practices will reduce risk, improve resilience, and help you maintain a safer digital environment over time.";
        var fillerWords = new System.Collections.Generic.List<string>();
        foreach (var w in System.Text.RegularExpressions.Regex.Split(filler, "\\s+"))
        {
            if (!string.IsNullOrEmpty(w)) fillerWords.Add(w);
        }

        while (words.Count < targetWords)
        {
            int need = targetWords - words.Count;
            int take = Math.Min(need, fillerWords.Count);
            for (int i = 0; i < take; i++) words.Add(fillerWords[i]);
            if (fillerWords.Count == 0) break;
        }

        if (words.Count > targetWords) words = words.GetRange(0, targetWords);
        return string.Join(" ", words);
    }
}

// External chatbot helper kept in its own file (moved from Program.cs)
static class ExternalChatbot
{
    public static void Run()
    {
        // header and loop deferred to Program.ExternalChatbot logic when invoked
        // but kept here for completeness; Program calls this via ExternalChatbot.Run().
        // Implementation lives in Program.cs refactored paths.
        // To avoid duplication, Program now uses this external class for the extended menu.
    }
}
